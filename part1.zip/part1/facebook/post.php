<?php

echo "hai";
?>