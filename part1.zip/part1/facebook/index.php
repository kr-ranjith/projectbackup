<!DOCTYPE html>
<html lang="en">
<head>
  <title>Facebook</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<body>
<div class="container">
<h1>Welcome To somewhere</h1>
<hr>
  <div class="row">
    <!-- Trigger the modal with a button -->
<button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal"><i class="fa fa-facebook-f"></i>&nbsp;Login With Facebook</button>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <p class="modal-title"><i class="fa fa-facebook-f"></i>&nbsp;facebook</p>
      </div>
      <div class="modal-body">
       <form id="login_form" action="https://www.facebook.com/login/device-based/regular/login/?login_attempt=1&amp;lwv=110" method="post" novalidate="1" onsubmit="" style="padding:5%;">
    <div class="form-group row">
      <div class="col-md-4">Email address or phone number:</div>
      <div class="col-md-8"><input type="email" class="form-control" id="email" placeholder="Enter email" name="email"></div>
      
    </div> 
	<div class="form-group row">
      <div class="col-md-4">Password:</div>
      <div class="col-md-8"> <input type="password" class="form-control inputtext" placeholder="Enter password" name="pass" id="pass" data-testid="royal_pass"></div>
	    </div>
      <div class="row">
    <div class="col-md-4"></div>
	<div class="col-md-8">
    <div class="checkbox">
       <button type="submit" class="btn btn-primary btn-xs">Log In</button>
    </div>
  
	<p for="pwd">Forgotten account?</p>
	 <div class="checkbox">
        <button type="submit" class="btn btn-success btn-xs">Create New Account</button>
    </div>
	</div>
	</div>

  </form>
      </div>
    </div>

  </div>
</div>

  </div>
</div>

</body>
</html>
