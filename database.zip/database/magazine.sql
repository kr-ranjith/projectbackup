-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 26, 2020 at 11:22 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `magazine`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cat_id` int(11) NOT NULL,
  `cat_name` text NOT NULL,
  `cat_content` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `cat_image` text NOT NULL,
  `cat_date` date NOT NULL,
  `time` varchar(200) NOT NULL,
  `ip` text NOT NULL,
  `device` text NOT NULL,
  `cat_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `cat_name`, `cat_content`, `meta_keyword`, `cat_image`, `cat_date`, `time`, `ip`, `device`, `cat_status`) VALUES
(6, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(7, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(8, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(9, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(10, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(11, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(13, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(14, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(15, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(16, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(17, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(18, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(19, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(20, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(21, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(22, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(23, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(24, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(25, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(26, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(27, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(28, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(29, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(30, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(31, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(32, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(33, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(34, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(35, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(36, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(37, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(38, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(39, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(40, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(41, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(42, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(43, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(44, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(45, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(46, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(47, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(48, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(49, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(50, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(51, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(52, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(53, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(54, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(55, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(56, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(57, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(58, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(59, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(60, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(61, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(62, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(63, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(64, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(65, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(66, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(67, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(68, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(69, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(70, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(71, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(72, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(73, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(74, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(75, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(76, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(77, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(78, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(79, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(80, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(81, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(82, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(83, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(84, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(85, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(86, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(87, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(88, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(89, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(90, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(91, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(92, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(93, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(94, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(95, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(96, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(97, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(98, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(100, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(101, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(102, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(103, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(104, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(105, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(106, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(107, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(108, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(109, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(110, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(111, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(112, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(113, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(114, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(115, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(116, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(117, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(123, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(124, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(126, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(127, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(128, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(129, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(130, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(131, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(132, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(134, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(135, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(136, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(138, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(139, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(140, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(141, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(143, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(144, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(145, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(146, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(147, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(148, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(149, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(150, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(152, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(153, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(154, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(155, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(156, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(159, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(160, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(161, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(162, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(164, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(165, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(169, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1),
(171, 'sfef', 'weq3etr', 'wfwewegt45ryu56', 'whytr45y', '2018-11-13', 'wger', 'grer', 'wegwergt', 1);

-- --------------------------------------------------------

--
-- Table structure for table `site_settings`
--

CREATE TABLE `site_settings` (
  `site_id` int(11) NOT NULL,
  `site_name` varchar(200) NOT NULL,
  `site_logo` text NOT NULL,
  `site_favicon` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sub_category`
--

CREATE TABLE `sub_category` (
  `sub_id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `sub_name` text NOT NULL,
  `sub_des` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `sub_image` text NOT NULL,
  `sub_date` date NOT NULL,
  `date` date NOT NULL,
  `time` text NOT NULL,
  `ip` text NOT NULL,
  `device` text NOT NULL,
  `sub_cat_satus` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE `tb_admin` (
  `adm_id` int(11) NOT NULL,
  `adm_name` varchar(200) NOT NULL,
  `adm_user` varchar(200) NOT NULL,
  `adm_pass` text NOT NULL,
  `adm_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_admin`
--

INSERT INTO `tb_admin` (`adm_id`, `adm_name`, `adm_user`, `adm_pass`, `adm_status`) VALUES
(1, '1', '1', 'c4ca4238a0b923820dcc509a6f75849b', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_articles`
--

CREATE TABLE `tb_articles` (
  `art_id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `sub_cat_id` int(11) NOT NULL,
  `art_title` text NOT NULL,
  `art_content` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `art_image` date NOT NULL,
  `art_date` text NOT NULL,
  `time` text NOT NULL,
  `device` text NOT NULL,
  `ip` text NOT NULL,
  `art_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_contactus`
--

CREATE TABLE `tb_contactus` (
  `contact_id` int(11) NOT NULL,
  `contact_name` text NOT NULL,
  `contact_email` text NOT NULL,
  `contact_phone` text NOT NULL,
  `contact_date` date NOT NULL,
  `time` text NOT NULL,
  `ip` text NOT NULL,
  `device` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_files`
--

CREATE TABLE `tb_files` (
  `file_id` int(11) NOT NULL,
  `file_type` int(11) NOT NULL,
  `file_name` text NOT NULL,
  `file_alt` text NOT NULL,
  `file_title` text NOT NULL,
  `file_location` text NOT NULL,
  `file_date` date NOT NULL,
  `time` text NOT NULL,
  `ip` text NOT NULL,
  `device` text NOT NULL,
  `file_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_page`
--

CREATE TABLE `tb_page` (
  `page_id` int(11) NOT NULL,
  `page_name` varchar(200) NOT NULL,
  `page_caontent` text NOT NULL,
  `page_metakeyword` text NOT NULL,
  `page_metadecription` text NOT NULL,
  `page_title` text NOT NULL,
  `page_template` text NOT NULL,
  `page_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_remainder`
--

CREATE TABLE `tb_remainder` (
  `rem_id` int(11) NOT NULL,
  `rem_name` text NOT NULL,
  `rem_title` text NOT NULL,
  `rem_content` text NOT NULL,
  `rem_post_date` date NOT NULL,
  `rem_date` date NOT NULL,
  `rem_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `site_settings`
--
ALTER TABLE `site_settings`
  ADD PRIMARY KEY (`site_id`);

--
-- Indexes for table `sub_category`
--
ALTER TABLE `sub_category`
  ADD PRIMARY KEY (`sub_id`);

--
-- Indexes for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`adm_id`);

--
-- Indexes for table `tb_articles`
--
ALTER TABLE `tb_articles`
  ADD PRIMARY KEY (`art_id`);

--
-- Indexes for table `tb_contactus`
--
ALTER TABLE `tb_contactus`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `tb_files`
--
ALTER TABLE `tb_files`
  ADD PRIMARY KEY (`file_id`);

--
-- Indexes for table `tb_page`
--
ALTER TABLE `tb_page`
  ADD PRIMARY KEY (`page_id`);

--
-- Indexes for table `tb_remainder`
--
ALTER TABLE `tb_remainder`
  ADD PRIMARY KEY (`rem_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=172;

--
-- AUTO_INCREMENT for table `site_settings`
--
ALTER TABLE `site_settings`
  MODIFY `site_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sub_category`
--
ALTER TABLE `sub_category`
  MODIFY `sub_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `adm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_articles`
--
ALTER TABLE `tb_articles`
  MODIFY `art_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_contactus`
--
ALTER TABLE `tb_contactus`
  MODIFY `contact_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_files`
--
ALTER TABLE `tb_files`
  MODIFY `file_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_page`
--
ALTER TABLE `tb_page`
  MODIFY `page_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_remainder`
--
ALTER TABLE `tb_remainder`
  MODIFY `rem_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
