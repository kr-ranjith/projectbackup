-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 26, 2020 at 11:27 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shoe_cart`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE `tb_admin` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `user_name` varchar(200) NOT NULL,
  `pass` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_admin`
--

INSERT INTO `tb_admin` (`id`, `name`, `user_name`, `pass`) VALUES
(1, 'admin', 'admin', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Table structure for table `tb_category`
--

CREATE TABLE `tb_category` (
  `cat_id` int(11) NOT NULL,
  `cat_name` varchar(15) NOT NULL,
  `cat_url` text NOT NULL,
  `cat_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_category`
--

INSERT INTO `tb_category` (`cat_id`, `cat_name`, `cat_url`, `cat_date`) VALUES
(1, 'mens', 'mens', '2018-09-08'),
(2, 'women', 'women', '2018-09-05'),
(3, 'child', 'child', '2018-09-12');

-- --------------------------------------------------------

--
-- Table structure for table `tb_color`
--

CREATE TABLE `tb_color` (
  `color_id` int(11) NOT NULL,
  `color_name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_color`
--

INSERT INTO `tb_color` (`color_id`, `color_name`) VALUES
(1, 'orange'),
(2, 'red'),
(3, 'yellow'),
(4, 'blue');

-- --------------------------------------------------------

--
-- Table structure for table `tb_product`
--

CREATE TABLE `tb_product` (
  `pro_id` int(10) NOT NULL,
  `pro_name` varchar(200) NOT NULL,
  `pro_price` float NOT NULL,
  `pro_category` varchar(200) NOT NULL,
  `pro_color` varchar(200) NOT NULL,
  `pro_size` int(11) NOT NULL,
  `pro_disc` text NOT NULL,
  `pro_date` date NOT NULL,
  `pro_stock` varchar(200) NOT NULL,
  `pro_image` varchar(200) NOT NULL,
  `pro_keyword` text NOT NULL,
  `pro_url` text NOT NULL,
  `pro_status` tinyint(20) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_product`
--

INSERT INTO `tb_product` (`pro_id`, `pro_name`, `pro_price`, `pro_category`, `pro_color`, `pro_size`, `pro_disc`, `pro_date`, `pro_stock`, `pro_image`, `pro_keyword`, `pro_url`, `pro_status`) VALUES
(11, 'Lorem Ipsum', 800, '1', '2', 32, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '2018-09-06', '22', 'model-size-one.jpg', '', 'lorem-ipsum-jack', NULL),
(10, 'Lorem Ipsum', 50, '2', '2', 32, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '2018-09-01', '2', 'model-size.jpg', '', 'lorem-ipsum', NULL),
(12, 'Lorem Ipsum red', 88, '1', '1', 32, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '2018-09-15', '3', 'model-size-sand.jpg', '', 'lorem-ipsum-jack-prt', NULL),
(13, 'Lorem Ipsum red blue', 50, '2', '3', 8, '', '2018-09-14', '5', 'model-size-leg.jpg', '', 'lorem-ipsum-jack-prot-offer', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `user_id` int(10) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `address1` text NOT NULL,
  `address2` varchar(200) NOT NULL,
  `address3` varchar(200) NOT NULL,
  `zipcode` text NOT NULL,
  `date` date NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`user_id`, `first_name`, `last_name`, `phone`, `email`, `address1`, `address2`, `address3`, `zipcode`, `date`, `username`, `password`) VALUES
(2, 'sreejith', 'KR', '8606193348', 'sreejithkr44@gmail.com', 'kalapurakkal', 'prapoil', 'cheruouzha', '670511', '2018-09-21', 'sreeskr', 'fbc6ee8f1f3d04721858f89e32aa85f6'),
(3, 'Ravi', 'KV', '9611124774', 'ranjithkr44@gmail.com', 'kalapurakkal', 'prapoil', 'cheruouzha', '670511', '2018-09-21', 'ravi', '9ab3b9b53cc61f1795166eecbbf0d355'),
(4, 'jagadamma', 'ad', '9611124774', 'ranjithkr44@gmail.com', 'kalapurakkal', 'prapoil', 'cheruouzha', '670511', '2018-09-21', 'jagada', '9ab3b9b53cc61f1795166eecbbf0d355'),
(5, 'Gayathri', 'Mohan', '9611124774', 'gaythri@gmail.cpom', 'kalapurakkal', 'prapoil', 'cheruouzha', '670511', '2018-09-21', 'jagada', '9ab3b9b53cc61f1795166eecbbf0d355'),
(6, 'Bala', 'Krishnan', '8086467632', 'blakrishnankv@gmail.com', 'kalapurakkal', 'prapoil', 'cheruouzha', '670511', '2018-09-21', 'balakrish', 'c975edb70f08229bbeb298dede828331'),
(7, 'Shaji', 'pappan', '9746785456', 'shajknarayan@gmail.com', 'Mantapam', 'narkilakkadu', 'kadumeni', '670511', '2018-09-21', 'shajipappan', '97eda66d0151f37b5ca43b817583e183'),
(8, 'knjamma', 'AD', '8086467632', 'kunjmma33@gmail.com', 'gad', 'city', 'uk', '670511', '2018-09-21', 'kunju33', 'd9eaf61aa32718c7e7eae380e597d47c'),
(9, 'rss', 'sss', '3333333333', 'ss@dd.cc', '22', '22', '22', '22', '2018-09-23', '', '3691308f2a4c2f6983f2880d32e29c84'),
(10, 'aaa', 'aaa', '33', 'aaa@s.dd', '33', '33', '33', '33', '2018-09-23', '333', '182be0c5cdcd5072bb1864cdee4d3d6e'),
(11, 'ammu', 'ammu', '8086467632', 'ammu@gmail.com', 'ammu', 'ammu', 'ammu', '4444', '2018-10-02', 'admin', '21232f297a57a5a743894a0e4a801fc3');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_category`
--
ALTER TABLE `tb_category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `tb_color`
--
ALTER TABLE `tb_color`
  ADD PRIMARY KEY (`color_id`);

--
-- Indexes for table `tb_product`
--
ALTER TABLE `tb_product`
  ADD PRIMARY KEY (`pro_id`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_category`
--
ALTER TABLE `tb_category`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_color`
--
ALTER TABLE `tb_color`
  MODIFY `color_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tb_product`
--
ALTER TABLE `tb_product`
  MODIFY `pro_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
