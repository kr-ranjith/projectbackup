-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 26, 2020 at 11:22 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `littlemisharlem`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(10) NOT NULL,
  `comment` varchar(150) NOT NULL,
  `post_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `comment`, `post_id`, `user_id`, `date`) VALUES
(1, 'lkjl;jljkl', 1, 2, '2018-12-24 21:34:54'),
(2, 'bnmbmm', 1, 0, '2018-12-24 20:09:19'),
(3, 'xvcxvx', 1, 0, '2018-12-24 20:11:59'),
(4, 'rtyryr', 1, 0, '2018-12-24 20:18:15'),
(5, 'rtyryr', 1, 0, '2018-12-24 20:20:53'),
(6, 'm,.....m.', 1, 0, '2018-12-24 20:21:30'),
(7, 'sdfsfsf', 1, 0, '2018-12-24 20:26:05'),
(8, 'sdfsfsf', 1, 0, '2018-12-24 20:26:31'),
(9, 'sdfsf', 1, 0, '2018-12-24 20:26:55'),
(10, 'fghfh', 1, 0, '2018-12-24 20:27:27'),
(11, 'yuyuyu', 1, 2, '2018-12-24 21:36:12'),
(12, 'kkkkkkkkkkkkkkk', 1, 2, '2018-12-24 21:37:36'),
(13, 'fgfggggggggg', 1, 2, '2018-12-24 21:38:00'),
(14, '', 10, 1, '2018-12-28 15:13:52'),
(15, '', 10, 1, '2018-12-28 15:13:58');

-- --------------------------------------------------------

--
-- Table structure for table `like_unlike`
--

CREATE TABLE `like_unlike` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `postid` int(11) NOT NULL,
  `type` int(2) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `like_unlike`
--

INSERT INTO `like_unlike` (`id`, `userid`, `postid`, `type`, `timestamp`) VALUES
(1, 2, 6, 1, '2018-12-21 16:16:23'),
(2, 2, 4, 1, '2018-12-21 16:18:16'),
(3, 3, 8, 1, '2018-12-24 16:42:27'),
(4, 3, 7, 1, '2018-12-24 16:42:46'),
(5, 1, 9, 1, '2018-12-28 14:44:07'),
(6, 1, 11, 1, '2019-01-03 14:50:10'),
(7, 1, 14, 1, '2019-01-03 18:02:12');

-- --------------------------------------------------------

--
-- Table structure for table `post_view`
--

CREATE TABLE `post_view` (
  `id` int(10) NOT NULL,
  `post_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tb_friends`
--

CREATE TABLE `tb_friends` (
  `friends_id` int(11) NOT NULL,
  `request_from` int(11) NOT NULL,
  `request_to` int(11) NOT NULL,
  `request_status` enum('0','1','2') NOT NULL,
  `request_date` date NOT NULL,
  `request_time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_friends`
--

INSERT INTO `tb_friends` (`friends_id`, `request_from`, `request_to`, `request_status`, `request_date`, `request_time`) VALUES
(1, 1, 3, '0', '2019-01-02', '11:23:49'),
(2, 4, 1, '0', '2019-01-02', '11:25:16');

-- --------------------------------------------------------

--
-- Table structure for table `tb_post`
--

CREATE TABLE `tb_post` (
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `post_comment` text NOT NULL,
  `post_file_name` text NOT NULL,
  `file_extension` varchar(11) NOT NULL,
  `post_date` date NOT NULL,
  `post_time` varchar(200) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_post`
--

INSERT INTO `tb_post` (`post_id`, `user_id`, `post_comment`, `post_file_name`, `file_extension`, `post_date`, `post_time`, `status`) VALUES
(2, 2, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam luctus hendrerit metus, ut ullamcorper quam finibus at. Etiam id magna sit amet...', 'desiner.PNG', '0', '2018-12-11', '', '1'),
(3, 2, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam luctus hendrerit metus, ut ullamcorper quam finibus at. Etiam id magna sit amet...', 'desiner.PNG', '0', '2018-12-12', '', '1'),
(4, 2, 'We hope your visit to math.com brings you a greater love of mathematics, both for its beauty and its power to help solve everyday problems.', 'alphabets-close-up-computer-532173.jpg', '0', '2018-12-12', '', '0'),
(5, 3, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam luctus hendrerit metus, ut ullamcorper quam finibus at. Etiam id magna sit amet...', 'DSC_0269.jpg', '0', '2018-12-12', '', '1'),
(6, 2, 'rrrrrrrrrrrr', 'chat.png', 'png', '2018-12-13', '11:57:11pm', '1'),
(7, 3, '', 'DSC_0269.jpg', 'jpg', '2018-12-14', '11:11:47pm', '1'),
(8, 3, 'dfsdfsdfd vjjjjjjjjjjjjjjjjjjjjjgfhggsgsgbvnhjjv ufjghjhgj', 'avatar2.jpg', 'jpg', '2018-12-20', '10:11:45pm', '1'),
(9, 1, 'cavvvvvvvvvvvvvvvvv', '48415667_2380407521986996_9120708888117641216_n.jpg', 'jpg', '2018-12-28', '08:13:53pm', '0'),
(10, 1, 'Looks like Deepika Padukone is not going to stop giving us fashion inspiration anytime soon. Be it bridal fashion goals or western ones, the diva never fails to disappoint us when it comes to fashion. We recently stumbled upon a couple of pics of her in a monokini for the cover shoot of a magazine and our jaws are dropped courtesy her hotness. The diva recently got married and as if her gorgeous pics from her wedding were not enough to sweep us off our feet, her new pictures have left us lovestruck.\r\n\r\n', 'slider2.jpg', 'jpg', '2018-12-28', '08:42:10pm', '1'),
(11, 1, 'gqindia@deepikapadukone\'s one of the most bankable Bollywood stars in the country and the only female star to have six films breach the ?100 crore box-office benchmark. She\'s also our coverstar of the #December2018 issue. Hit the link in bio to get your copy NOW. Photographed by Tibi Clenci (@tibiclenci)\n', '1544084986-deepika_mag_cover.jpg', 'jpg', '2018-12-28', '08:43:34pm', '1'),
(12, 1, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'anniversary-157248_640.png', 'png', '2019-01-02', '08:16:51pm', '1'),
(13, 1, '$this->db->select(\'*\');\n$this->db->from(\'table1\');\n$this->db->join(\'table2\', \'table1.col1 = table2.col1\');\n$this->db->where(\'table1.col1\', 2);\n\n$query = $this->db->get();', 'photoshoot-2913930_1920.jpg', 'jpg', '2019-01-02', '09:31:40pm', '0'),
(14, 1, '#8 SHAREHOLDER VALUE (6-1) showed improved early speed in his first start after the Eddie Kenneally claim on Nov. 2, and the runner-up was a next-out winner. The fresh gelding is back at his winning distance and figures to stalk the pace under Jose Ortiz. He was part of the trifecta in his last five starts. \r\n\r\n\r\n#2 Brasstown (3-1) exits back-to-back front running wins, including a sharp score at this course/distance Dec. 6. They might not catch him if he gets a clear early lead. \r\n\r\n\r\n#1 Third Day (4-1) might be ready to deliver a top effort in his third start after a layoff. The lightly raced 5-year-old was pushed out of position early in a local flat mile affair Dec. 7. He is bred to handle two turns and should save all of the ground stalking the pace under Irad Ortiz Jr. ', 'photoshoot-2913930_1920.jpg', 'jpg', '2019-01-02', '09:31:40pm', '1');

-- --------------------------------------------------------

--
-- Table structure for table `user_registration`
--

CREATE TABLE `user_registration` (
  `id` int(10) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `question` varchar(100) NOT NULL,
  `answer` varchar(100) NOT NULL,
  `gender` enum('m','f') NOT NULL,
  `user_type` enum('g','p') NOT NULL COMMENT 'g:girl ,p:parent',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_registration`
--

INSERT INTO `user_registration` (`id`, `fname`, `lname`, `password`, `email`, `phone`, `question`, `answer`, `gender`, `user_type`, `created_at`) VALUES
(1, 'Remya', 'kk', '21232f297a57a5a743894a0e4a801fc3', 'ranjithkr44@gmail.com', '2222222222', '2', '222', '', 'g', '2019-01-02 14:58:11'),
(3, 'sewak', 'deshmukh', '0e7517141fb53f21ee439b355b5a1d0a', 'sewakdeshmukh19@gmail.com', '9689279541', '1', '771990', '', 'g', '2018-12-10 07:00:00'),
(4, 'ss', 'aa', '202cb962ac59075b964b07152d234b70', 'admin@gmail.com', '4444444444', '2', 'zzzzzzzzzzzzzz', '', 'g', '2018-12-11 07:00:00'),
(5, 'ss', 'aa', '202cb962ac59075b964b07152d234b70', 'admin@gmail.com', '4444444444', '2', 'zzzzzzzzzzzzzz', '', 'g', '2018-12-11 07:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `post_id` (`post_id`);

--
-- Indexes for table `like_unlike`
--
ALTER TABLE `like_unlike`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post_view`
--
ALTER TABLE `post_view`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_friends`
--
ALTER TABLE `tb_friends`
  ADD PRIMARY KEY (`friends_id`);

--
-- Indexes for table `tb_post`
--
ALTER TABLE `tb_post`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `user_registration`
--
ALTER TABLE `user_registration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `like_unlike`
--
ALTER TABLE `like_unlike`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `post_view`
--
ALTER TABLE `post_view`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_friends`
--
ALTER TABLE `tb_friends`
  MODIFY `friends_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_post`
--
ALTER TABLE `tb_post`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `user_registration`
--
ALTER TABLE `user_registration`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
